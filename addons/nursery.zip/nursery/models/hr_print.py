from odoo import models, fields

class HrPrintModel(models.Model):
    _inherit = "hr.payslip"

    def print_button_action(self):
        print("this sucks!")